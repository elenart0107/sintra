﻿using System;

namespace DemonstratieOperatoren
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.BufferWidth = 600;
            //Console.WindowWidth = 300;

            #region Unairy
            //int rijNummer = 0;

            //rijNummer++;
            //rijNummer++;
            //rijNummer--;
            // rijNummer = 1

            //Console.WriteLine(++rijNummer);
            #endregion

            #region delen door nul
            //int resultaat = 15 / 0; // Compile time error

            //int getalNul = 0;
            //int resultaat = 15 / getalNul; //Runtime error
            #endregion

            #region casting
            //float resultaat = 16 / 3;
            //resultaat = 16f / 3f;

            //double resultaatDouble = 16f / 3f;

            //float resultaatFloat = (float)(16d / 3d);

            //Console.WriteLine(resultaatDouble);
            //Console.WriteLine(resultaatFloat);

            //int resultaatInt = (int)(16f / 3f);
            //Console.WriteLine(resultaatInt);
            #endregion

            #region Modulo
            //int teller = 16;
            //int noemer = 3;
            //int resultaatModulo = teller % noemer;
            //int resultaatManueel;

            //float deling = teller / noemer;
            //int geheelDeelVanDeling = (int)deling;

            //resultaatManueel = teller - (geheelDeelVanDeling * noemer);

            //Console.WriteLine(resultaatManueel);
            //Console.WriteLine(resultaatModulo);
            #endregion

            #region Boolean operators

            // AND (&&)
            // 1 0
            bool resultaat;
            bool mijnNaamIsThijs = true;
            bool ikHebEenHond = false;

            //Console.WriteLine($"Is mijn naam thijs: {mijnNaamIsThijs}");
            //Console.WriteLine($"heb Ik een hond: {ikHebEenHond}");

            //resultaat = mijnNaamIsThijs && ikHebEenHond;
            //Console.WriteLine($"Is mijn naam thijs AND heb ik een hond: {resultaat}");

            // 1 1
            //mijnNaamIsThijs = true;
            //ikHebEenHond = true;

            //Console.WriteLine($"Is mijn naam thijs: {mijnNaamIsThijs}");
            //Console.WriteLine($"heb Ik een hond: {ikHebEenHond}");

            //resultaat = mijnNaamIsThijs && ikHebEenHond;
            //Console.WriteLine($"Is mijn naam thijs AND heb ik een hond: {resultaat}");


            // OR (||)

            //0 1
            bool mijnNaamIsMargarete = false;
            //ikHebEenHond = true;

            //Console.WriteLine($"Is mijn naam Margarete: {mijnNaamIsMargarete}");
            //Console.WriteLine($"heb Ik een hond: {ikHebEenHond}");

            //resultaat = mijnNaamIsMargarete || ikHebEenHond;
            //Console.WriteLine($"Is mijn naam Margarete OR heb ik een hond: {resultaat}");

            //mijnNaamIsMargarete = false;
            //ikHebEenHond = false;

            //Console.WriteLine($"Is mijn naam Margarete: {mijnNaamIsMargarete}");
            //Console.WriteLine($"heb Ik een hond: {ikHebEenHond}");

            //resultaat = mijnNaamIsMargarete || ikHebEenHond;
            //Console.WriteLine($"Is mijn naam Margarete OR heb ik een hond: {resultaat}");


            //XOR (^)
            // 1 1
            //bool rijstTaart = true;
            //bool dameBlanche = true;

            //Console.WriteLine($"rijst taart: {rijstTaart}");
            //Console.WriteLine($"dame blanche: {dameBlanche}");

            //resultaat = rijstTaart ^ dameBlanche;
            //Console.WriteLine($"Krijg ik dessert!: {resultaat}");

            //// 0 1
            //rijstTaart = false;
            //dameBlanche = true;

            //Console.WriteLine($"rijst taart: {rijstTaart}");
            //Console.WriteLine($"dame blanche: {dameBlanche}");

            //resultaat = rijstTaart ^ dameBlanche;
            //Console.WriteLine($"Krijg ik dessert!: {resultaat}");

            //NOT (!)
            // 0
            //bool geenOnderhoudNodig = false;
            //Console.WriteLine("Geen onderhoud nodig: " + geenOnderhoudNodig);

            //resultaat = !geenOnderhoudNodig;
            //Console.WriteLine($"Heeft mijn wagen onderhoud nodig : {resultaat}");


            //// 1
            //geenOnderhoudNodig = true;
            //Console.WriteLine("Geen onderhoud nodig: " + geenOnderhoudNodig);

            //resultaat = !geenOnderhoudNodig;
            //Console.WriteLine($"Heeft mijn wagen onderhoud nodig : {resultaat}");
            #endregion

            #region Vergelijkings Operatoren
            bool isToegelaten;
            int leeftijd = 18;

            isToegelaten = leeftijd > 17; // leeftijd >= 18
            //Console.WriteLine($"Ik ben {leeftijd} jaar oud, ben ik toegelaten {isToegelaten}");

            //
            leeftijd = 55;
            int minToegelatenLeeftijd = 16;
            int maxToegelatenLeeftijd = 50;

            //isToegelaten = leeftijd >= minToegelatenLeeftijd && leeftijd <= maxToegelatenLeeftijd;
            //Console.WriteLine($"Moet ik gaan strijden: {isToegelaten}");

            // ==
            //string ingegevenWachtwoord = Console.ReadLine();
            //string echtWachtwoord = "DameBlanchGod";

            //bool isIngelogd = ingegevenWachtwoord == echtWachtwoord;
            //Console.WriteLine($"Ben ik ingelog: {isIngelogd}");

            // !=
            //string ingegevenNaam = Console.ReadLine();
            //string verbodenNaam = "Wilhelm";
            //string verbodenNaam2 = "Adolf";

            //bool isNaamToegelaten = ingegevenNaam != verbodenNaam;
            ////Console.WriteLine($"Is Naam toegelaten: {isNaamToegelaten}");

            //isNaamToegelaten = (ingegevenNaam != verbodenNaam) && (ingegevenNaam != verbodenNaam2);
            //Console.WriteLine($"Is Naam toegelaten: {isNaamToegelaten}");
            #endregion

            #region
            // MAX
            int leeftijd1 = 40;
            int leeftijd2 = 44;
            int toegelatenLeeftijd = 45;

            int grootsteLeeftijd = Math.Max(leeftijd1, leeftijd2);

            isToegelaten = grootsteLeeftijd >= toegelatenLeeftijd;
            //Console.WriteLine($"Zijn wij toegelaten in de Gents Club: {isToegelaten}");

            // MIN
            float diameter1 = 2.25f;
            float diameter2 = 5.55f;
            float diameter3 = 1.50f;
            float diameter4 = 3.8f;
            float kleinsteBal;
            
            kleinsteBal = Math.Min(diameter1, diameter2);
            kleinsteBal = Math.Min(kleinsteBal, diameter3);
            kleinsteBal = Math.Min(kleinsteBal, diameter4);

            //kleinsteBal = Math.Min(Math.Min(diameter1, diameter2), diameter3);
            //Console.WriteLine($"De diameter van de kleinste bal is {kleinsteBal}");

            // volgerde input parameters is belangrijk
            double res = Math.Pow(5, 2);
            Console.WriteLine($"resultaat is: {res}");
            #endregion

        }
    }
}
